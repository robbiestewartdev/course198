# simple-FSK
A simple FSK modulation and demodulation in verilog. Tested in Zedboard+FMCOMMS3 
2020-02-25 : 上传通过仿真的文件，此文件还没有进行下板运行。
