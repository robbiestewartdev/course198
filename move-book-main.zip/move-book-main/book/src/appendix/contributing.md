# Appendix D: Contributing

To contribute to this book, please, submit a pull request to the
[GitHub repository](https://github.com/MystenLabs/move-book). The repository contains the source
files for the book, written in mdBook format.
