# Appendix C: Publications

This section lists publications related to Move and Sui.

- [The Move Borrow Checker](https://arxiv.org/abs/2205.05181) by Sam Blackshear, John Mitchell, Todd
  Nowacki, Shaz Qadeer.
- [Resources: A Safe Language Abstraction for Money](https://arxiv.org/abs/2004.05106) by Sam
  Blackshear, David L. Dill, Shaz Qadeer, Clark W. Barrett, John C. Mitchell, Oded Padon, Yoni
  Zohar.
- [Robust Safety for Move](https://arxiv.org/abs/2110.05043) by Marco Patrignani, Sam Blackshear
