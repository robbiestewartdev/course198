# Appendix E: Acknowledgements

[The Rust Book](https://doc.rust-lang.org/book) has been a great inspiration for this book. I am
personally grateful to the authors of the book, Steve Klabnik and Carol Nichols, for their work, as
I have learned a lot from it. This book is a small tribute to their work and an attempt to bring a
similar learning experience to the Move community.
