# Authorization Patterns
