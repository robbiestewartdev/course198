# Introduction

Welcome to The Move Book, a book about Move language.

> If you're looking for The Move Reference, it is available here: [The Move Reference](/reference). The reference focuses on the language itself, while this book is structured as a learning path, starting with the basics and moving on to more advanced topics. The link to reference is always available at the top of the page, similarly, there's a link to the book at the top of the reference page.

<!--

## Who Move Is For?

Move

## Who This Book Is For

## How To Use This Book



This book is a comprehensive guide to the language and the platform, and it is intended for developers who want to learn how to write application in Move and build on Sui.

 -->

<!-- Author? -->

<!-- This is a book about the Move language and the Sui blockchain platform. It is a comprehensive guide to the language and the platform, and it is intended for developers who want to learn how to write application in Move and build on Sui. -->
