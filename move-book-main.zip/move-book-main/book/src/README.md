# The Move Book

<!-- TODO: insert author(s) -->

This is the Move Book - a comprehensive guide to the Move programming language and the Sui blockchain. The book is intended for developers who are interested in learning about Move and building on Sui.

<div class="warning">

The book is in active development and a work in progress. If you have any feedback or suggestions, feel free to open an issue or a pull request on the [GitHub repository](https://github.com/MystenLabs/move-book).

</div>

> If you're looking for The Move Reference, you can find it [here](/reference).
