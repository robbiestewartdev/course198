# Transfer to Object?

The `transfer::transfer` call takes the receiver `address` as the second argument, and while in most
of the cases it is an account address, it can also be an address of an object. In this case,
