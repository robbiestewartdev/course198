# Before we begin

Move requires an environment to run and develop applications, and in this small chapter we will
cover the prerequisites for the Move language: how to set up your IDE, how to install the compiler
and what is Move 2024. If you are already familiar with these topics or have a CLI installed, you
can skip this chapter and proceed to [the next one](../your-first-move/hello-world.md).
