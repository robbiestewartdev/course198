# Remote Cluster with Terraform and Ansible

See the [docs](https://docs.tendermint.com/v0.34/networks/terraform-and-ansible.html).
