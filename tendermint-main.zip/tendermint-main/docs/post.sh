#!/bin/bash

rm -rf ./.vuepress/public/rpc
