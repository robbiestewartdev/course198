---
order: 9
---

# RPC

The RPC documentation is hosted here:

- [https://docs.tendermint.com/v0.34/rpc/](https://docs.tendermint.com/v0.34/rpc/)

To update the documentation, edit the relevant `godoc` comments in the [rpc/core directory](https://github.com/tendermint/tendermint/blob/v0.34.x/rpc/core).
