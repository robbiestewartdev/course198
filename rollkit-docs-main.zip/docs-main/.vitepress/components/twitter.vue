
<template>
	<blockquote class="twitter-tweet" data-lang="en" data-theme="dark">
		<p lang="de" dir="ltr">rollkit start <a href="https://t.co/tytjFm1Z4Y">pic.twitter.com/tytjFm1Z4Y</a></p>&mdash; Josh Stein 🤳✨ (@JoshCStein) <a href="https://twitter.com/JoshCStein/status/1783880747301880161?ref_src=twsrc%5Etfw">April 26, 2024</a>
	</blockquote>
</template>

<script>
export default {
    name: 'Twitter',
}
</script>

<style scoped>
/* Add any custom styles for the component here */
</style>
