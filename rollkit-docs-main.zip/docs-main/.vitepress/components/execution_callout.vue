<template>
    <div>
        <p>Rollkit is currently undergoing an execution overhaul with the
        creation of the <a
        href="https://github.com/rollkit/go-execution">go-execution
        interface</a>. In the meantime, the execution tutorials should be
        considered out of date until they have been updated to use the new
        execution API.  If you have question about a specific execution
        environment, please create a GitHub <a
        href="https://github.com/rollkit/docs/issues/new">issue ticket</a> or
        reach out in our <a href="https://t.me/rollkit">Telegram group</a>.</p>
    </div>
</template>

<script>
export default {
    name: 'ExecutionCallout',
}
</script>

<style scoped>
/* Add any custom styles for the component here */
</style>