<template>
    <div>
        <p>This tutorial explores Rollkit, currently in Alpha. If you encounter bugs, please report them via a GitHub <a href="https://github.com/rollkit/docs/issues/new">issue ticket</a> or reach out in our <a href="https://t.me/rollkit">Telegram group</a>.</p>
    </div>
</template>

<script>
export default {
    name: 'Callout',
}
</script>

<style scoped>
/* Add any custom styles for the component here */
</style>