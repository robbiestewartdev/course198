# Introduction

Welcome to the Rollkit docs. We're happy you made it here!
Rollkit allows anyone to launch an unstoppable blockchain as easily as a smart contract.

Rollkit is the unstoppable stack.

We're setting the bar high for developers' flexibility and ability to customize blockchains however they see fit.
